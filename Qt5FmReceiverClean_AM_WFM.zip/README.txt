Qt5 FM Receiver Clean + AM/WFM
==============================

Добавлено:
- выбор режима демодуляции:
  1) NFM / узкая FM
  2) WFM / широкая FM
  3) AM
- AM-демодуляция через envelope detector sqrt(I^2 + Q^2)
- WFM-режим с более широкой аудиополосой
- исправлен soft limiter: qTan() заменён на qTanH()
- сохранены DC-block, Noise filter, Notch 19 kHz, WAV-запись, спектр, счётчики и gain

Важно:
- Для настоящей широковещательной WFM желательно иметь IQ sample rate выше 96 кГц.
  При 96 кГц программа всё равно работает, но полноценную широкую FM-полосу она физически не захватит.
- Для вашей учебной FM-передачи режим NFM обычно будет самым подходящим.
- AM заработает только если на входе реально AM-сигнал.

Сборка:
1) qmake Qt5FmReceiverClean.pro
2) make

или Windows MinGW:
1) qmake Qt5FmReceiverClean.pro
2) mingw32-make
