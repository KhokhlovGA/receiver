#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class QLineEdit;
class QPushButton;
class QLabel;
class QSlider;
class QComboBox;
class QCheckBox;
class QPlainTextEdit;
class QProgressBar;
class FmReceiver;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    void onStartStopClicked();
    void onLevelUpdated(float level01);
    void onPacketCounterUpdated(quint64 count);
    void onLossCounterUpdated(quint64 count);
    void onBufferUpdated(int bytes);
    void appendStatus(const QString &text);

private:
    void buildUi();

    FmReceiver *m_receiver;

    QLineEdit *m_ipEdit;
    QLineEdit *m_portEdit;
    QPushButton *m_startStopButton;
    QSlider *m_volumeSlider;
    QComboBox *m_deempCombo;
    QCheckBox *m_autoGainCheck;
    QCheckBox *m_dcBlockCheck;

    QLabel *m_stateLabel;
    QLabel *m_packetsLabel;
    QLabel *m_lossLabel;
    QLabel *m_bufferLabel;
    QProgressBar *m_levelBar;
    QPlainTextEdit *m_log;
};

#endif // MAINWINDOW_H
