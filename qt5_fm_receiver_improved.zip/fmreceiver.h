#ifndef FMRECEIVER_H
#define FMRECEIVER_H

#include <QObject>
#include <QUdpSocket>
#include <QAudioOutput>
#include <QIODevice>
#include <QVector>
#include <QByteArray>
#include <QHostAddress>

class AudioBufferDevice : public QIODevice
{
    Q_OBJECT
public:
    explicit AudioBufferDevice(QObject *parent = nullptr);

    void start();
    void stop();
    qint64 readData(char *data, qint64 maxlen) override;
    qint64 writeData(const char *data, qint64 len) override;
    qint64 bytesAvailable() const override;

    void appendPcm16Mono(const QVector<qint16> &samples);
    int bufferedBytes() const;
    void clear();

private:
    QByteArray m_buffer;
    int m_readPos;
};

class FmReceiver : public QObject
{
    Q_OBJECT
public:
    explicit FmReceiver(QObject *parent = nullptr);
    ~FmReceiver();

    bool start(const QHostAddress &bindAddress, quint16 port);
    void stop();
    bool isRunning() const;

    void setVolumePercent(int value);
    void setDeemphasisUs(double value);
    void setAutoGainEnabled(bool enabled);
    void setDcBlockEnabled(bool enabled);

signals:
    void statusMessage(const QString &text);
    void levelUpdated(float level01);
    void packetCounterUpdated(quint64 packets);
    void lossCounterUpdated(quint64 lostPackets);
    void bufferUpdated(int bytesBuffered);

private slots:
    void onReadyRead();

private:
    struct PacketInfo {
        QVector<float> iq;
        quint16 counter;
    };

    bool parsePacket(const QByteArray &datagram, PacketInfo &out);
    QVector<float> fmDemod(const QVector<float> &iq);
    QVector<float> dcBlock(const QVector<float> &x);
    QVector<float> deEmphasis(const QVector<float> &x);
    QVector<float> lowPassAndDecimate2(const QVector<float> &x);
    QVector<qint16> floatToPcm16(const QVector<float> &x);

    QUdpSocket *m_udp;
    QAudioOutput *m_audio;
    AudioBufferDevice *m_audioDevice;

    bool m_running;
    quint64 m_packets;
    quint64 m_lostPackets;
    bool m_autoGainEnabled;
    bool m_dcBlockEnabled;

    bool m_havePrevCounter;
    quint16 m_prevCounter;

    float m_prevI;
    float m_prevQ;

    float m_dcX1;
    float m_dcY1;

    float m_deempY1;
    double m_deemphasisUs;

    float m_gainSmoothed;
};

#endif // FMRECEIVER_H
