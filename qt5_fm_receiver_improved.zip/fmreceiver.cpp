#include "fmreceiver.h"

#include <QtMath>
#include <QAudioFormat>
#include <algorithm>

static const int HEADER_SIZE = 24;
static const int SAMPLES_PER_PACKET = 350;
static const int BYTES_PER_COMPLEX_INT16 = 4;
static const quint8 RX_PACKET_ID = 0x52;
static const int INPUT_SAMPLE_RATE = 96000;
static const int OUTPUT_SAMPLE_RATE = 48000;

AudioBufferDevice::AudioBufferDevice(QObject *parent)
    : QIODevice(parent),
      m_readPos(0)
{
}

void AudioBufferDevice::start()
{
    open(QIODevice::ReadOnly);
}

void AudioBufferDevice::stop()
{
    close();
    clear();
}

void AudioBufferDevice::clear()
{
    m_buffer.clear();
    m_readPos = 0;
}

qint64 AudioBufferDevice::readData(char *data, qint64 maxlen)
{
    const qint64 available = m_buffer.size() - m_readPos;
    if (available <= 0) {
        memset(data, 0, size_t(maxlen));
        return maxlen;
    }

    const qint64 toRead = qMin(maxlen, available);
    memcpy(data, m_buffer.constData() + m_readPos, size_t(toRead));
    m_readPos += int(toRead);

    if (toRead < maxlen) {
        memset(data + toRead, 0, size_t(maxlen - toRead));
    }

    if (m_readPos > 32768) {
        m_buffer.remove(0, m_readPos);
        m_readPos = 0;
    }

    return maxlen;
}

qint64 AudioBufferDevice::writeData(const char *, qint64)
{
    return -1;
}

qint64 AudioBufferDevice::bytesAvailable() const
{
    return (m_buffer.size() - m_readPos) + QIODevice::bytesAvailable();
}

void AudioBufferDevice::appendPcm16Mono(const QVector<qint16> &samples)
{
    if (samples.isEmpty())
        return;

    const int appendBytes = samples.size() * int(sizeof(qint16));
    const int oldSize = m_buffer.size();
    m_buffer.resize(oldSize + appendBytes);
    memcpy(m_buffer.data() + oldSize, samples.constData(), size_t(appendBytes));

    const int maxBytes = OUTPUT_SAMPLE_RATE * 2 * 3 / 2;
    if (m_buffer.size() > maxBytes) {
        const int drop = m_buffer.size() - maxBytes;
        m_buffer.remove(0, drop);
        m_readPos = qMax(0, m_readPos - drop);
    }
}

int AudioBufferDevice::bufferedBytes() const
{
    return m_buffer.size() - m_readPos;
}

FmReceiver::FmReceiver(QObject *parent)
    : QObject(parent),
      m_udp(new QUdpSocket(this)),
      m_audio(nullptr),
      m_audioDevice(new AudioBufferDevice(this)),
      m_running(false),
      m_packets(0),
      m_lostPackets(0),
      m_autoGainEnabled(true),
      m_dcBlockEnabled(true),
      m_havePrevCounter(false),
      m_prevCounter(0),
      m_prevI(1.0f),
      m_prevQ(0.0f),
      m_dcX1(0.0f),
      m_dcY1(0.0f),
      m_deempY1(0.0f),
      m_deemphasisUs(50.0),
      m_gainSmoothed(0.15f)
{
    connect(m_udp, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

FmReceiver::~FmReceiver()
{
    stop();
}

bool FmReceiver::start(const QHostAddress &bindAddress, quint16 port)
{
    if (m_running)
        stop();

    QAudioFormat fmt;
    fmt.setSampleRate(OUTPUT_SAMPLE_RATE);
    fmt.setChannelCount(1);
    fmt.setSampleSize(16);
    fmt.setCodec("audio/pcm");
    fmt.setByteOrder(QAudioFormat::LittleEndian);
    fmt.setSampleType(QAudioFormat::SignedInt);

    m_audio = new QAudioOutput(fmt, this);
    m_audio->setBufferSize(8192);
    m_audio->setVolume(0.7);

    m_audioDevice->clear();
    m_audioDevice->start();
    m_audio->start(m_audioDevice);

    const bool ok = m_udp->bind(bindAddress, port,
                                QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    if (!ok) {
        emit statusMessage(QString::fromUtf8("Ошибка bind UDP: ") + m_udp->errorString());
        if (m_audio) {
            m_audio->stop();
            m_audio->deleteLater();
            m_audio = nullptr;
        }
        m_audioDevice->stop();
        return false;
    }

    m_packets = 0;
    m_lostPackets = 0;
    m_havePrevCounter = false;
    m_prevI = 1.0f;
    m_prevQ = 0.0f;
    m_dcX1 = m_dcY1 = 0.0f;
    m_deempY1 = 0.0f;
    m_gainSmoothed = 0.15f;
    m_running = true;

    emit packetCounterUpdated(0);
    emit lossCounterUpdated(0);
    emit bufferUpdated(0);
    emit levelUpdated(0.0f);
    emit statusMessage(QString::fromUtf8("Приём запущен: %1:%2").arg(bindAddress.toString()).arg(port));
    return true;
}

void FmReceiver::stop()
{
    if (m_udp->state() == QUAbstractSocket::BoundState)
        m_udp->close();

    if (m_audio) {
        m_audio->stop();
        m_audio->deleteLater();
        m_audio = nullptr;
    }

    m_audioDevice->stop();

    if (m_running)
        emit statusMessage(QString::fromUtf8("Приём остановлен"));

    m_running = false;
}

bool FmReceiver::isRunning() const
{
    return m_running;
}

void FmReceiver::setVolumePercent(int value)
{
    if (m_audio)
        m_audio->setVolume(qBound(0, value, 100) / 100.0);
}

void FmReceiver::setDeemphasisUs(double value)
{
    m_deemphasisUs = value;
}

void FmReceiver::setAutoGainEnabled(bool enabled)
{
    m_autoGainEnabled = enabled;
}

void FmReceiver::setDcBlockEnabled(bool enabled)
{
    m_dcBlockEnabled = enabled;
}

bool FmReceiver::parsePacket(const QByteArray &datagram, PacketInfo &out)
{
    if (datagram.size() < HEADER_SIZE + SAMPLES_PER_PACKET * BYTES_PER_COMPLEX_INT16)
        return false;

    const uchar *p = reinterpret_cast<const uchar*>(datagram.constData());
    if (p[0] != RX_PACKET_ID)
        return false;

    const quint16 sampleCount = (quint16(p[2]) << 8) | quint16(p[3]);
    if (sampleCount != SAMPLES_PER_PACKET)
        return false;

    out.counter = (quint16(p[6]) << 8) | quint16(p[7]);
    out.iq.resize(sampleCount * 2);

    const uchar *s = p + HEADER_SIZE;
    for (int i = 0; i < sampleCount; ++i) {
        const int pos = i * 4;
        const qint16 i16 = qint16(quint16(s[pos]) | (quint16(s[pos + 1]) << 8));
        const qint16 q16 = qint16(quint16(s[pos + 2]) | (quint16(s[pos + 3]) << 8));
        out.iq[2 * i] = float(i16) / 32768.0f;
        out.iq[2 * i + 1] = float(q16) / 32768.0f;
    }

    return true;
}

QVector<float> FmReceiver::fmDemod(const QVector<float> &iq)
{
    const int nComplex = iq.size() / 2;
    QVector<float> y(nComplex, 0.0f);

    for (int i = 0; i < nComplex; ++i) {
        const float ci = iq[2 * i];
        const float cq = iq[2 * i + 1];

        const float re = m_prevI * ci + m_prevQ * cq;
        const float im = m_prevI * cq - m_prevQ * ci;

        y[i] = std::atan2(im, re);

        m_prevI = ci;
        m_prevQ = cq;
    }

    return y;
}

QVector<float> FmReceiver::dcBlock(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);
    const float R = 0.995f;

    for (int i = 0; i < x.size(); ++i) {
        const float xn = x[i];
        const float yn = xn - m_dcX1 + R * m_dcY1;
        y[i] = yn;
        m_dcX1 = xn;
        m_dcY1 = yn;
    }

    return y;
}

QVector<float> FmReceiver::deEmphasis(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);

    const double dt = 1.0 / double(INPUT_SAMPLE_RATE);
    const double tau = m_deemphasisUs * 1e-6;
    const float a = float(dt / (tau + dt));

    for (int i = 0; i < x.size(); ++i) {
        m_deempY1 = m_deempY1 + a * (x[i] - m_deempY1);
        y[i] = m_deempY1;
    }

    return y;
}

QVector<float> FmReceiver::lowPassAndDecimate2(const QVector<float> &x)
{
    QVector<float> y;
    y.reserve(x.size() / 2 + 1);

    for (int i = 0; i + 1 < x.size(); i += 2) {
        const float s = 0.5f * (x[i] + x[i + 1]);
        y.push_back(s);
    }

    return y;
}

QVector<qint16> FmReceiver::floatToPcm16(const QVector<float> &x)
{
    QVector<qint16> pcm;
    pcm.reserve(x.size());

    float peak = 1e-6f;
    for (int i = 0; i < x.size(); ++i)
        peak = qMax(peak, qAbs(x[i]));

    float gain = 14000.0f;
    if (m_autoGainEnabled) {
        const float target = 0.35f;
        const float wanted = target / peak;
        m_gainSmoothed = 0.98f * m_gainSmoothed + 0.02f * wanted;
        gain = qBound(2000.0f, m_gainSmoothed * 14000.0f, 28000.0f);
    }

    for (int i = 0; i < x.size(); ++i) {
        float s = x[i] * gain;
        if (s > 32767.0f) s = 32767.0f;
        if (s < -32768.0f) s = -32768.0f;
        pcm.push_back(qint16(s));
    }

    return pcm;
}

void FmReceiver::onReadyRead()
{
    while (m_udp->hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(int(m_udp->pendingDatagramSize()));
        m_udp->readDatagram(datagram.data(), datagram.size());

        PacketInfo packet;
        if (!parsePacket(datagram, packet))
            continue;

        if (m_havePrevCounter) {
            const quint16 expected = quint16(m_prevCounter + 1);
            if (packet.counter != expected) {
                const quint16 diff = quint16(packet.counter - expected);
                m_lostPackets += diff;
                emit lossCounterUpdated(m_lostPackets);
            }
        }
        m_prevCounter = packet.counter;
        m_havePrevCounter = true;

        QVector<float> demod = fmDemod(packet.iq);
        if (m_dcBlockEnabled)
            demod = dcBlock(demod);
        demod = deEmphasis(demod);
        demod = lowPassAndDecimate2(demod);

        float peak = 0.0f;
        for (int i = 0; i < demod.size(); ++i)
            peak = qMax(peak, qAbs(demod[i]));
        emit levelUpdated(qMin(1.0f, peak * 2.5f));

        const QVector<qint16> pcm = floatToPcm16(demod);
        m_audioDevice->appendPcm16Mono(pcm);

        ++m_packets;
        emit packetCounterUpdated(m_packets);
        emit bufferUpdated(m_audioDevice->bufferedBytes());

        if ((m_packets % 200) == 0) {
            emit statusMessage(QString::fromUtf8("Пакеты: %1, потери: %2, аудио-буфер: %3 байт")
                               .arg(m_packets)
                               .arg(m_lostPackets)
                               .arg(m_audioDevice->bufferedBytes()));
        }
    }
}
