#include "fmreceiver.h"

#include <QAudioFormat>
#include <QCoreApplication>
#include <QDateTime>
#include <QDebug>
#include <QHostAddress>
#include <QMutex>
#include <QMutexLocker>
#include <QtEndian>
#include <cmath>

namespace {
const int HEADER_SIZE = 24;
const int SAMPLES_PER_PACKET = 350;
const int IQ_WORDS_PER_PACKET = SAMPLES_PER_PACKET * 2;
const int INPUT_SAMPLE_RATE = 96000;
const int OUTPUT_SAMPLE_RATE = 48000;
const quint8 RX_PACKET_ID = 0x52; // 'R'
const quint8 SAMPLE_FORMAT = 0x11;
const float DEEMPH_TAU = 50e-6f;
}

AudioBufferDevice::AudioBufferDevice(QObject *parent)
    : QIODevice(parent), m_mutex(new QMutex)
{
}

qint64 AudioBufferDevice::readData(char *data, qint64 maxSize)
{
    QMutexLocker locker(m_mutex);
    const qint64 n = qMin(maxSize, qint64(m_buffer.size()));
    if (n > 0) {
        memcpy(data, m_buffer.constData(), size_t(n));
        m_buffer.remove(0, int(n));
    } else {
        memset(data, 0, size_t(maxSize));
        return maxSize;
    }
    if (n < maxSize) {
        memset(data + n, 0, size_t(maxSize - n));
        return maxSize;
    }
    return n;
}

qint64 AudioBufferDevice::writeData(const char *, qint64)
{
    return -1;
}

qint64 AudioBufferDevice::bytesAvailable() const
{
    QMutexLocker locker(m_mutex);
    return m_buffer.size() + QIODevice::bytesAvailable();
}

void AudioBufferDevice::pushPcm16(const QByteArray &chunk)
{
    QMutexLocker locker(m_mutex);
    m_buffer.append(chunk);
    const int maxBuffered = OUTPUT_SAMPLE_RATE * 2 * 2; // ~2 sec mono int16
    if (m_buffer.size() > maxBuffered) {
        m_buffer.remove(0, m_buffer.size() - maxBuffered);
    }
}

FmReceiver::FmReceiver(const QString &bindIp, quint16 port, QObject *parent)
    : QObject(parent),
      m_audio(0),
      m_audioDevice(0),
      m_bindAddress(bindIp),
      m_port(port),
      m_havePrev(false),
      m_prevI(0.0f),
      m_prevQ(0.0f),
      m_dcY(0.0f),
      m_dcX(0.0f),
      m_deemphY(0.0f),
      m_resamplePhase(0.0f),
      m_prevAudio(0.0f),
      m_currAudio(0.0f),
      m_packets(0),
      m_badPackets(0),
      m_lastCounter(0),
      m_haveCounter(false)
{
}

bool FmReceiver::start()
{
    QAudioFormat format;
    format.setSampleRate(OUTPUT_SAMPLE_RATE);
    format.setChannelCount(1);
    format.setSampleSize(16);
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::SignedInt);

    m_audio = new QAudioOutput(format, this);
    m_audio->setBufferSize(OUTPUT_SAMPLE_RATE / 2);
    m_audio->setNotifyInterval(1000);
    connect(m_audio, SIGNAL(notify()), this, SLOT(onAudioNotify()));

    m_audioDevice = new AudioBufferDevice(this);
    m_audioDevice->open(QIODevice::ReadOnly);
    m_audio->start(m_audioDevice);

    connect(&m_socket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));

    const bool ok = m_socket.bind(m_bindAddress, m_port,
                                  QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    if (!ok) {
        qCritical() << "UDP bind error:" << m_socket.errorString();
        return false;
    }

    qInfo() << "Listening UDP" << m_bindAddress.toString() << ":" << m_port;
    qInfo() << "Expecting packets: id=0x52, 24-byte header, 350 complex int16 IQ @ 96 kHz";
    return true;
}

void FmReceiver::onReadyRead()
{
    while (m_socket.hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(int(m_socket.pendingDatagramSize()));
        QHostAddress peer;
        quint16 peerPort = 0;
        if (m_socket.readDatagram(datagram.data(), datagram.size(), &peer, &peerPort) < 0) {
            qWarning() << "readDatagram error:" << m_socket.errorString();
            continue;
        }
        if (!processPacket(datagram)) {
            ++m_badPackets;
        }
    }
}

void FmReceiver::onAudioNotify()
{
    qInfo() << "packets:" << m_packets
            << "bad:" << m_badPackets
            << "audio queued bytes:" << m_audioDevice->bytesAvailable();
}

bool FmReceiver::processPacket(const QByteArray &datagram)
{
    if (datagram.size() != HEADER_SIZE + IQ_WORDS_PER_PACKET * 2) {
        return false;
    }

    const uchar *p = reinterpret_cast<const uchar *>(datagram.constData());
    if (p[0] != RX_PACKET_ID || p[1] != SAMPLE_FORMAT) {
        return false;
    }

    const quint16 sampleCount = qFromBigEndian<quint16>(p + 2);
    const quint16 counter = qFromBigEndian<quint16>(p + 6);
    if (sampleCount != SAMPLES_PER_PACKET) {
        return false;
    }

    if (m_haveCounter) {
        const quint16 diff = quint16(counter - m_lastCounter);
        if (diff != 1) {
            qWarning() << "packet gap, expected" << quint16(m_lastCounter + 1) << "got" << counter;
        }
    }
    m_lastCounter = counter;
    m_haveCounter = true;

    const qint16 *iq = reinterpret_cast<const qint16 *>(p + HEADER_SIZE);
    QByteArray pcm = demodulateToPcm(iq, SAMPLES_PER_PACKET);
    m_audioDevice->pushPcm16(pcm);
    ++m_packets;
    return true;
}

QByteArray FmReceiver::demodulateToPcm(const qint16 *iq, int complexCount)
{
    QByteArray pcm;
    pcm.reserve(complexCount * 2);

    const float dt = 1.0f / float(INPUT_SAMPLE_RATE);
    const float alpha = dt / (DEEMPH_TAU + dt);
    const float dcAlpha = 0.995f;
    const float audioGain = 12000.0f;
    const float decimRatio = float(INPUT_SAMPLE_RATE) / float(OUTPUT_SAMPLE_RATE); // 2.0

    for (int n = 0; n < complexCount; ++n) {
        const qint16 rawI = qFromLittleEndian<qint16>(reinterpret_cast<const uchar *>(&iq[2 * n]));
        const qint16 rawQ = qFromLittleEndian<qint16>(reinterpret_cast<const uchar *>(&iq[2 * n + 1]));

        const float i = float(rawI) / 32768.0f;
        const float q = float(rawQ) / 32768.0f;

        float fm = 0.0f;
        if (m_havePrev) {
            const float re = i * m_prevI + q * m_prevQ;
            const float im = q * m_prevI - i * m_prevQ;
            fm = std::atan2(im, re);
        } else {
            m_havePrev = true;
        }

        m_prevI = i;
        m_prevQ = q;

        // simple DC blocker
        m_dcY = fm - m_dcX + dcAlpha * m_dcY;
        m_dcX = fm;

        // de-emphasis
        m_deemphY = m_deemphY + alpha * (m_dcY - m_deemphY);
        const float audio = m_deemphY;

        // 96 kHz -> 48 kHz linear interpolation
        m_currAudio = audio;
        m_resamplePhase += 1.0f;
        while (m_resamplePhase >= decimRatio) {
            const float frac = (m_resamplePhase - decimRatio);
            const float t = frac; // for decimRatio==2 gives 0 or 1 progression
            const float y = m_prevAudio + (m_currAudio - m_prevAudio) * t;
            const qint16 s = clamp16(y * audioGain);
            pcm.append(char(s & 0xff));
            pcm.append(char((s >> 8) & 0xff));
            m_resamplePhase -= decimRatio;
        }
        m_prevAudio = m_currAudio;
    }

    return pcm;
}

qint16 FmReceiver::clamp16(float x)
{
    if (x > 32767.0f) {
        return 32767;
    }
    if (x < -32768.0f) {
        return -32768;
    }
    return qint16(x);
}
