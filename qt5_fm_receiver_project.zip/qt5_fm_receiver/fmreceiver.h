#ifndef FMRECEIVER_H
#define FMRECEIVER_H

#include <QObject>
#include <QUdpSocket>
#include <QAudioOutput>
#include <QIODevice>
#include <QByteArray>
#include <QtGlobal>

class AudioBufferDevice : public QIODevice
{
    Q_OBJECT
public:
    explicit AudioBufferDevice(QObject *parent = 0);

    bool isSequential() const override { return true; }
    qint64 readData(char *data, qint64 maxSize) override;
    qint64 writeData(const char *data, qint64 maxSize) override;
    qint64 bytesAvailable() const override;

    void pushPcm16(const QByteArray &chunk);

private:
    QByteArray m_buffer;
    mutable QMutex *m_mutex;
};

class FmReceiver : public QObject
{
    Q_OBJECT
public:
    explicit FmReceiver(const QString &bindIp,
                        quint16 port,
                        QObject *parent = 0);

    bool start();

private slots:
    void onReadyRead();
    void onAudioNotify();

private:
    bool processPacket(const QByteArray &datagram);
    QByteArray demodulateToPcm(const qint16 *iq, int complexCount);
    static qint16 clamp16(float x);

    QUdpSocket m_socket;
    QAudioOutput *m_audio;
    AudioBufferDevice *m_audioDevice;
    QHostAddress m_bindAddress;
    quint16 m_port;

    bool m_havePrev;
    float m_prevI;
    float m_prevQ;
    float m_dcY;
    float m_dcX;
    float m_deemphY;
    float m_resamplePhase;
    float m_prevAudio;
    float m_currAudio;
    quint32 m_packets;
    quint32 m_badPackets;
    quint16 m_lastCounter;
    bool m_haveCounter;
};

#endif // FMRECEIVER_H
