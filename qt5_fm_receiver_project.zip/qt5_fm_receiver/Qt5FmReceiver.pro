QT += core network multimedia
CONFIG += console c++11
CONFIG -= app_bundle
TEMPLATE = app

SOURCES += \
    main.cpp \
    fmreceiver.cpp

HEADERS += \
    fmreceiver.h
