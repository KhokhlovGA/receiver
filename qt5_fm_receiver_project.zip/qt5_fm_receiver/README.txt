Qt5 FM audio receiver for your Zedboard + AD9361 project.

What it does:
- listens on UDP port 60000 by default
- accepts your packet format: 24-byte header + 350 complex int16 IQ samples
- FM-demodulates the IQ stream
- applies simple DC blocking and 50 us de-emphasis
- converts 96 kHz to 48 kHz
- plays audio through the default sound card

Build with qmake (Qt 5):
1) Open Qt 5 command prompt or terminal with qmake in PATH
2) Run:
   qmake Qt5FmReceiver.pro
   make

On Windows with MinGW:
   qmake Qt5FmReceiver.pro
   mingw32-make

Run:
   Qt5FmReceiver.exe --ip 192.168.200.63 --port 60000
or:
   Qt5FmReceiver.exe --ip 0.0.0.0 --port 60000

Notes:
- Your board sends little-endian int16 IQ payload.
- If you still hear only noise, first verify the RF side:
  * RX frequency on the board must match the transmitted signal
  * TX leakage can overload RX if TX and RX are too close
  * for same-frequency TX/RX you usually need strong isolation: separate antennas, attenuator, duplexer/circulator, shielding
- If the audio is too quiet or too loud, change audioGain in fmreceiver.cpp.
