#include <QCoreApplication>
#include <QCommandLineOption>
#include <QCommandLineParser>
#include <QHostAddress>
#include <QTextStream>
#include "fmreceiver.h"

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("Qt5FmReceiver");
    QCoreApplication::setApplicationVersion("1.0");

    QCommandLineParser parser;
    parser.setApplicationDescription("Qt5 UDP FM receiver for Zedboard/AD9361 IQ stream");
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption ipOpt(QStringList() << "i" << "ip",
                             "Local IP to bind.", "ip", "0.0.0.0");
    QCommandLineOption portOpt(QStringList() << "p" << "port",
                               "UDP port.", "port", "60000");
    parser.addOption(ipOpt);
    parser.addOption(portOpt);
    parser.process(app);

    const QString ip = parser.value(ipOpt);
    bool ok = false;
    const quint16 port = parser.value(portOpt).toUShort(&ok);
    if (!ok) {
        QTextStream(stderr) << "Bad port\n";
        return 1;
    }

    FmReceiver rx(ip, port);
    if (!rx.start()) {
        return 1;
    }

    return app.exec();
}
