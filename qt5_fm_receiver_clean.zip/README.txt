Qt5 FM Receiver Clean
=====================

Что именно изменено против прошлой версии:
- добавлен IQ DC-block ДО FM демодуляции
- простая децимация заменена на FIR decimate-by-2
- добавлен аудио low-pass после децимации
- добавлен мягкий limiter
- добавлен опциональный notch 19 kHz
- сохранены WAV, лёгкий спектр, счётчики, gain, mute

Зачем это нужно:
- писк часто появляется из-за высокочастотного мусора после FM demod
- шум усиливается из-за слишком грубой децимации
- DC и паразитные тоны в IQ тоже портят звук

Что попробовать первым:
1) Noise filter = ON
2) DC-block = ON
3) Auto gain = ON
4) Notch 19 kHz = OFF

Если писк останется:
- включи Notch 19 kHz
- попробуй уменьшить Output Gain
- попробуй 75 us / 50 us

Сборка:
1) qmake Qt5FmReceiverClean.pro
2) make

или на Windows:
1) qmake Qt5FmReceiverClean.pro
2) mingw32-make
