QT += core gui network multimedia widgets
CONFIG += c++11
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    fmreceiver.cpp

HEADERS += \
    mainwindow.h \
    fmreceiver.h
