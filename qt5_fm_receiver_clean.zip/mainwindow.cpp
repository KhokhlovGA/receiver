#include "mainwindow.h"
#include "fmreceiver.h"

#include <QVBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QSlider>
#include <QComboBox>
#include <QCheckBox>
#include <QPlainTextEdit>
#include <QProgressBar>
#include <QDateTime>
#include <QHostAddress>
#include <QMessageBox>
#include <QPainter>
#include <QFileDialog>

SpectrumWidget::SpectrumWidget(QWidget *parent)
    : QWidget(parent)
{
    setMinimumHeight(180);
}

void SpectrumWidget::setSpectrum(const QVector<float> &values)
{
    m_values = values;
    update();
}

void SpectrumWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.fillRect(rect(), QColor(20, 22, 24));

    p.setPen(QColor(55, 60, 65));
    for (int i = 0; i <= 8; ++i) {
        int x = i * width() / 8;
        p.drawLine(x, 0, x, height());
    }
    for (int i = 0; i <= 6; ++i) {
        int y = i * height() / 6;
        p.drawLine(0, y, width(), y);
    }

    p.setPen(QColor(180, 180, 180));
    p.drawText(8, 16, "-48 кГц");
    p.drawText(width() / 2 - 10, 16, "0");
    p.drawText(width() - 58, 16, "+48 кГц");

    if (m_values.isEmpty()) {
        p.drawText(rect(), Qt::AlignCenter, QString::fromUtf8("Лёгкий спектр IQ"));
        return;
    }

    QPolygon poly;
    poly.reserve(m_values.size());

    const float minDb = -90.0f;
    const float maxDb = 0.0f;

    for (int i = 0; i < m_values.size(); ++i) {
        const float normX = (m_values.size() == 1) ? 0.0f : float(i) / float(m_values.size() - 1);
        float v = (m_values[i] - minDb) / (maxDb - minDb);
        if (v < 0.0f) v = 0.0f;
        if (v > 1.0f) v = 1.0f;
        const int x = int(normX * (width() - 1));
        const int y = int((1.0f - v) * (height() - 1));
        poly << QPoint(x, y);
    }

    p.setRenderHint(QPainter::Antialiasing, true);
    p.setPen(QPen(QColor(0, 210, 110), 2));
    p.drawPolyline(poly);
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      m_receiver(new FmReceiver(this))
{
    buildUi();

    connect(m_receiver, SIGNAL(statusMessage(QString)), this, SLOT(appendStatus(QString)));
    connect(m_receiver, SIGNAL(levelUpdated(float)), this, SLOT(onLevelUpdated(float)));
    connect(m_receiver, SIGNAL(packetCounterUpdated(quint64)), this, SLOT(onPacketCounterUpdated(quint64)));
    connect(m_receiver, SIGNAL(lossCounterUpdated(quint64)), this, SLOT(onLossCounterUpdated(quint64)));
    connect(m_receiver, SIGNAL(bufferUpdated(int)), this, SLOT(onBufferUpdated(int)));
    connect(m_receiver, SIGNAL(spectrumUpdated(QVector<float>)), this, SLOT(onSpectrumUpdated(QVector<float>)));
    connect(m_receiver, SIGNAL(recordingStateChanged(bool,QString)), this, SLOT(onRecordingStateChanged(bool,QString)));
}

void MainWindow::buildUi()
{
    setWindowTitle(QString::fromUtf8("Qt5 FM Receiver Clean"));
    resize(940, 760);

    QWidget *central = new QWidget(this);
    setCentralWidget(central);
    QVBoxLayout *root = new QVBoxLayout(central);

    QGroupBox *controlBox = new QGroupBox(QString::fromUtf8("Параметры приёма"), this);
    QGridLayout *grid = new QGridLayout(controlBox);

    grid->addWidget(new QLabel("Bind IP:", this), 0, 0);
    m_ipEdit = new QLineEdit("192.168.200.63", this);
    grid->addWidget(m_ipEdit, 0, 1);

    grid->addWidget(new QLabel(QString::fromUtf8("UDP порт:")), 0, 2);
    m_portEdit = new QLineEdit("60000", this);
    grid->addWidget(m_portEdit, 0, 3);

    m_startStopButton = new QPushButton(QString::fromUtf8("Старт"), this);
    grid->addWidget(m_startStopButton, 0, 4);

    m_recordButton = new QPushButton(QString::fromUtf8("Запись WAV"), this);
    grid->addWidget(m_recordButton, 0, 5);

    grid->addWidget(new QLabel(QString::fromUtf8("Громкость:")), 1, 0);
    m_volumeSlider = new QSlider(Qt::Horizontal, this);
    m_volumeSlider->setRange(0, 100);
    m_volumeSlider->setValue(70);
    grid->addWidget(m_volumeSlider, 1, 1, 1, 2);

    grid->addWidget(new QLabel(QString::fromUtf8("Выходной gain:")), 1, 3);
    m_outputGainSlider = new QSlider(Qt::Horizontal, this);
    m_outputGainSlider->setRange(20, 300);
    m_outputGainSlider->setValue(100);
    grid->addWidget(m_outputGainSlider, 1, 4, 1, 2);

    grid->addWidget(new QLabel(QString::fromUtf8("De-emphasis:")), 2, 0);
    m_deempCombo = new QComboBox(this);
    m_deempCombo->addItem("50 us", 50.0);
    m_deempCombo->addItem("75 us", 75.0);
    grid->addWidget(m_deempCombo, 2, 1);

    m_autoGainCheck = new QCheckBox(QString::fromUtf8("Автоусиление"), this);
    m_autoGainCheck->setChecked(true);
    grid->addWidget(m_autoGainCheck, 2, 2);

    m_dcBlockCheck = new QCheckBox(QString::fromUtf8("DC-block"), this);
    m_dcBlockCheck->setChecked(true);
    grid->addWidget(m_dcBlockCheck, 2, 3);

    m_muteCheck = new QCheckBox(QString::fromUtf8("Mute"), this);
    m_muteCheck->setChecked(false);
    grid->addWidget(m_muteCheck, 2, 4);

    m_noiseFilterCheck = new QCheckBox(QString::fromUtf8("Noise filter"), this);
    m_noiseFilterCheck->setChecked(true);
    grid->addWidget(m_noiseFilterCheck, 3, 0, 1, 2);

    m_notch19kCheck = new QCheckBox(QString::fromUtf8("Notch 19 kHz"), this);
    m_notch19kCheck->setChecked(false);
    grid->addWidget(m_notch19kCheck, 3, 2, 1, 2);

    root->addWidget(controlBox);

    QGroupBox *statusBox = new QGroupBox(QString::fromUtf8("Состояние"), this);
    QGridLayout *sgrid = new QGridLayout(statusBox);

    m_stateLabel = new QLabel(QString::fromUtf8("Остановлен"), this);
    m_packetsLabel = new QLabel(QString::fromUtf8("Пакеты: 0"), this);
    m_lossLabel = new QLabel(QString::fromUtf8("Потери: 0"), this);
    m_bufferLabel = new QLabel(QString::fromUtf8("Аудио-буфер: 0 байт"), this);
    m_recordLabel = new QLabel(QString::fromUtf8("WAV: не пишется"), this);

    m_levelBar = new QProgressBar(this);
    m_levelBar->setRange(0, 100);
    m_levelBar->setValue(0);
    m_levelBar->setFormat(QString::fromUtf8("Уровень FM: %p%"));

    sgrid->addWidget(new QLabel(QString::fromUtf8("Режим:")), 0, 0);
    sgrid->addWidget(m_stateLabel, 0, 1);
    sgrid->addWidget(m_packetsLabel, 1, 0);
    sgrid->addWidget(m_lossLabel, 1, 1);
    sgrid->addWidget(m_bufferLabel, 2, 0);
    sgrid->addWidget(m_recordLabel, 2, 1);
    sgrid->addWidget(m_levelBar, 3, 0, 1, 2);

    root->addWidget(statusBox);

    QGroupBox *specBox = new QGroupBox(QString::fromUtf8("Лёгкий спектр IQ"), this);
    QVBoxLayout *specLayout = new QVBoxLayout(specBox);
    m_spectrum = new SpectrumWidget(this);
    specLayout->addWidget(m_spectrum);
    root->addWidget(specBox);

    QGroupBox *logBox = new QGroupBox(QString::fromUtf8("Журнал"), this);
    QVBoxLayout *logLayout = new QVBoxLayout(logBox);
    m_log = new QPlainTextEdit(this);
    m_log->setReadOnly(true);
    logLayout->addWidget(m_log);
    root->addWidget(logBox, 1);

    connect(m_startStopButton, SIGNAL(clicked()), this, SLOT(onStartStopClicked()));
    connect(m_recordButton, SIGNAL(clicked()), this, SLOT(onRecordClicked()));
    connect(m_volumeSlider, &QSlider::valueChanged, [this](int value) { m_receiver->setVolumePercent(value); });
    connect(m_outputGainSlider, &QSlider::valueChanged, [this](int value) { m_receiver->setOutputGainPercent(value); });
    connect(m_deempCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), [this](int index) {
        m_receiver->setDeemphasisUs(m_deempCombo->itemData(index).toDouble());
    });
    connect(m_autoGainCheck, &QCheckBox::toggled, [this](bool on) { m_receiver->setAutoGainEnabled(on); });
    connect(m_dcBlockCheck, &QCheckBox::toggled, [this](bool on) { m_receiver->setDcBlockEnabled(on); });
    connect(m_muteCheck, &QCheckBox::toggled, [this](bool on) { m_receiver->setMuteEnabled(on); });
    connect(m_noiseFilterCheck, &QCheckBox::toggled, [this](bool on) { m_receiver->setNoiseFilterEnabled(on); });
    connect(m_notch19kCheck, &QCheckBox::toggled, [this](bool on) { m_receiver->setNotch19kEnabled(on); });

    appendStatus(QString::fromUtf8("Версия Clean: IQ DC-block + лучший decimate + audio low-pass. Это должно убрать часть писка и шипения."));
}

void MainWindow::onStartStopClicked()
{
    if (!m_receiver->isRunning()) {
        QHostAddress addr;
        if (!addr.setAddress(m_ipEdit->text().trimmed())) {
            QMessageBox::warning(this, QString::fromUtf8("Ошибка"), QString::fromUtf8("Неверный IP адрес."));
            return;
        }

        bool ok = false;
        const quint16 port = m_portEdit->text().toUShort(&ok);
        if (!ok || port == 0) {
            QMessageBox::warning(this, QString::fromUtf8("Ошибка"), QString::fromUtf8("Неверный UDP порт."));
            return;
        }

        m_receiver->setVolumePercent(m_volumeSlider->value());
        m_receiver->setOutputGainPercent(m_outputGainSlider->value());
        m_receiver->setDeemphasisUs(m_deempCombo->currentData().toDouble());
        m_receiver->setAutoGainEnabled(m_autoGainCheck->isChecked());
        m_receiver->setDcBlockEnabled(m_dcBlockCheck->isChecked());
        m_receiver->setMuteEnabled(m_muteCheck->isChecked());
        m_receiver->setNoiseFilterEnabled(m_noiseFilterCheck->isChecked());
        m_receiver->setNotch19kEnabled(m_notch19kCheck->isChecked());

        if (m_receiver->start(addr, port)) {
            m_stateLabel->setText(QString::fromUtf8("Приём идёт"));
            m_startStopButton->setText(QString::fromUtf8("Стоп"));
        }
    } else {
        if (m_receiver->isRecording())
            m_receiver->stopRecordingWav();
        m_receiver->stop();
        m_stateLabel->setText(QString::fromUtf8("Остановлен"));
        m_startStopButton->setText(QString::fromUtf8("Старт"));
    }
}

void MainWindow::onRecordClicked()
{
    if (!m_receiver->isRecording()) {
        const QString fileName = QFileDialog::getSaveFileName(
            this,
            QString::fromUtf8("Сохранить WAV"),
            "fm_capture.wav",
            "WAV files (*.wav)");
        if (fileName.isEmpty())
            return;
        m_receiver->startRecordingWav(fileName);
    } else {
        m_receiver->stopRecordingWav();
    }
}

void MainWindow::onLevelUpdated(float level01)
{
    m_levelBar->setValue(qBound(0, int(level01 * 100.0f), 100));
}

void MainWindow::onPacketCounterUpdated(quint64 count)
{
    m_packetsLabel->setText(QString::fromUtf8("Пакеты: %1").arg(count));
}

void MainWindow::onLossCounterUpdated(quint64 count)
{
    m_lossLabel->setText(QString::fromUtf8("Потери: %1").arg(count));
}

void MainWindow::onBufferUpdated(int bytes)
{
    m_bufferLabel->setText(QString::fromUtf8("Аудио-буфер: %1 байт").arg(bytes));
}

void MainWindow::onSpectrumUpdated(const QVector<float> &values)
{
    m_spectrum->setSpectrum(values);
}

void MainWindow::onRecordingStateChanged(bool recording, const QString &fileName)
{
    m_recordButton->setText(recording ? QString::fromUtf8("Стоп записи") : QString::fromUtf8("Запись WAV"));
    if (recording)
        m_recordLabel->setText(QString::fromUtf8("WAV: %1").arg(fileName));
    else
        m_recordLabel->setText(QString::fromUtf8("WAV: не пишется"));
}

void MainWindow::appendStatus(const QString &text)
{
    const QString t = QDateTime::currentDateTime().toString("HH:mm:ss");
    m_log->appendPlainText(QString("[%1] %2").arg(t, text));
}
