#include "fmreceiver.h"

#include <QtMath>
#include <QAudioFormat>
#include <QDataStream>
#include <algorithm>

static const int HEADER_SIZE = 24;
static const int SAMPLES_PER_PACKET = 350;
static const int BYTES_PER_COMPLEX_INT16 = 4;
static const quint8 RX_PACKET_ID = 0x52;
static const int INPUT_SAMPLE_RATE = 96000;
static const int OUTPUT_SAMPLE_RATE = 48000;

AudioBufferDevice::AudioBufferDevice(QObject *parent)
    : QIODevice(parent), m_readPos(0)
{
}

void AudioBufferDevice::start()
{
    open(QIODevice::ReadOnly);
}

void AudioBufferDevice::stop()
{
    close();
    clear();
}

void AudioBufferDevice::clear()
{
    m_buffer.clear();
    m_readPos = 0;
}

qint64 AudioBufferDevice::readData(char *data, qint64 maxlen)
{
    const qint64 available = m_buffer.size() - m_readPos;
    if (available <= 0) {
        memset(data, 0, size_t(maxlen));
        return maxlen;
    }

    const qint64 toRead = qMin(maxlen, available);
    memcpy(data, m_buffer.constData() + m_readPos, size_t(toRead));
    m_readPos += int(toRead);

    if (toRead < maxlen)
        memset(data + toRead, 0, size_t(maxlen - toRead));

    if (m_readPos > 32768) {
        m_buffer.remove(0, m_readPos);
        m_readPos = 0;
    }

    return maxlen;
}

qint64 AudioBufferDevice::writeData(const char *, qint64)
{
    return -1;
}

qint64 AudioBufferDevice::bytesAvailable() const
{
    return (m_buffer.size() - m_readPos) + QIODevice::bytesAvailable();
}

void AudioBufferDevice::appendPcm16Mono(const QVector<qint16> &samples)
{
    if (samples.isEmpty())
        return;

    const int appendBytes = samples.size() * int(sizeof(qint16));
    const int oldSize = m_buffer.size();
    m_buffer.resize(oldSize + appendBytes);
    memcpy(m_buffer.data() + oldSize, samples.constData(), size_t(appendBytes));

    const int maxBytes = OUTPUT_SAMPLE_RATE * 2 * 2;
    if (m_buffer.size() > maxBytes) {
        const int drop = m_buffer.size() - maxBytes;
        m_buffer.remove(0, drop);
        m_readPos = qMax(0, m_readPos - drop);
    }
}

int AudioBufferDevice::bufferedBytes() const
{
    return m_buffer.size() - m_readPos;
}

FmReceiver::FmReceiver(QObject *parent)
    : QObject(parent),
      m_udp(new QUdpSocket(this)),
      m_audio(nullptr),
      m_audioDevice(new AudioBufferDevice(this)),
      m_running(false),
      m_packets(0),
      m_lostPackets(0),
      m_autoGainEnabled(true),
      m_dcBlockEnabled(true),
      m_muteEnabled(false),
      m_noiseFilterEnabled(true),
      m_notch19kEnabled(false),
      m_havePrevCounter(false),
      m_prevCounter(0),
      m_prevI(1.0f),
      m_prevQ(0.0f),
      m_iqDcI_x1(0.0f),
      m_iqDcI_y1(0.0f),
      m_iqDcQ_x1(0.0f),
      m_iqDcQ_y1(0.0f),
      m_dcX1(0.0f),
      m_dcY1(0.0f),
      m_deempY1(0.0f),
      m_lpf1(0.0f),
      m_lpf2(0.0f),
      m_notch_x1(0.0f),
      m_notch_x2(0.0f),
      m_notch_y1(0.0f),
      m_notch_y2(0.0f),
      m_deemphasisUs(50.0),
      m_gainSmoothed(0.15f),
      m_manualOutputGain(1.0f),
      m_lastSpectrumPacket(0),
      m_wavDataBytes(0)
{
    connect(m_udp, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

FmReceiver::~FmReceiver()
{
    stopRecordingWav();
    stop();
}

bool FmReceiver::start(const QHostAddress &bindAddress, quint16 port)
{
    if (m_running)
        stop();

    QAudioFormat fmt;
    fmt.setSampleRate(OUTPUT_SAMPLE_RATE);
    fmt.setChannelCount(1);
    fmt.setSampleSize(16);
    fmt.setCodec("audio/pcm");
    fmt.setByteOrder(QAudioFormat::LittleEndian);
    fmt.setSampleType(QAudioFormat::SignedInt);

    m_audio = new QAudioOutput(fmt, this);
    m_audio->setBufferSize(8192);
    m_audio->setVolume(0.7);

    m_audioDevice->clear();
    m_audioDevice->start();
    m_audio->start(m_audioDevice);

    const bool ok = m_udp->bind(bindAddress, port,
                                QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    if (!ok) {
        emit statusMessage(QString::fromUtf8("Ошибка bind UDP: ") + m_udp->errorString());
        if (m_audio) {
            m_audio->stop();
            m_audio->deleteLater();
            m_audio = nullptr;
        }
        m_audioDevice->stop();
        return false;
    }

    m_packets = 0;
    m_lostPackets = 0;
    m_havePrevCounter = false;
    m_prevI = 1.0f;
    m_prevQ = 0.0f;
    m_iqDcI_x1 = m_iqDcI_y1 = 0.0f;
    m_iqDcQ_x1 = m_iqDcQ_y1 = 0.0f;
    m_dcX1 = m_dcY1 = 0.0f;
    m_deempY1 = 0.0f;
    m_lpf1 = m_lpf2 = 0.0f;
    m_notch_x1 = m_notch_x2 = 0.0f;
    m_notch_y1 = m_notch_y2 = 0.0f;
    m_gainSmoothed = 0.15f;
    m_lastSpectrumPacket = 0;
    m_running = true;

    emit packetCounterUpdated(0);
    emit lossCounterUpdated(0);
    emit bufferUpdated(0);
    emit levelUpdated(0.0f);
    emit statusMessage(QString::fromUtf8("Приём запущен: %1:%2").arg(bindAddress.toString()).arg(port));
    return true;
}

void FmReceiver::stop()
{
    if (m_udp->state() == QUAbstractSocket::BoundState)
        m_udp->close();

    if (m_audio) {
        m_audio->stop();
        m_audio->deleteLater();
        m_audio = nullptr;
    }

    m_audioDevice->stop();

    if (m_running)
        emit statusMessage(QString::fromUtf8("Приём остановлен"));

    m_running = false;
}

bool FmReceiver::isRunning() const
{
    return m_running;
}

void FmReceiver::setVolumePercent(int value) { if (m_audio) m_audio->setVolume(qBound(0, value, 100) / 100.0); }
void FmReceiver::setDeemphasisUs(double value) { m_deemphasisUs = value; }
void FmReceiver::setAutoGainEnabled(bool enabled) { m_autoGainEnabled = enabled; }
void FmReceiver::setDcBlockEnabled(bool enabled) { m_dcBlockEnabled = enabled; }
void FmReceiver::setMuteEnabled(bool enabled) { m_muteEnabled = enabled; }
void FmReceiver::setNoiseFilterEnabled(bool enabled) { m_noiseFilterEnabled = enabled; }
void FmReceiver::setNotch19kEnabled(bool enabled) { m_notch19kEnabled = enabled; }

void FmReceiver::setOutputGainPercent(int value)
{
    m_manualOutputGain = qBound(0, value, 300) / 100.0f;
}

bool FmReceiver::parsePacket(const QByteArray &datagram, PacketInfo &out)
{
    if (datagram.size() < HEADER_SIZE + SAMPLES_PER_PACKET * BYTES_PER_COMPLEX_INT16)
        return false;

    const uchar *p = reinterpret_cast<const uchar*>(datagram.constData());
    if (p[0] != RX_PACKET_ID)
        return false;

    const quint16 sampleCount = (quint16(p[2]) << 8) | quint16(p[3]);
    if (sampleCount != SAMPLES_PER_PACKET)
        return false;

    out.counter = (quint16(p[6]) << 8) | quint16(p[7]);
    out.iq.resize(sampleCount * 2);

    const uchar *s = p + HEADER_SIZE;
    for (int i = 0; i < sampleCount; ++i) {
        const int pos = i * 4;
        const qint16 i16 = qint16(quint16(s[pos]) | (quint16(s[pos + 1]) << 8));
        const qint16 q16 = qint16(quint16(s[pos + 2]) | (quint16(s[pos + 3]) << 8));
        out.iq[2 * i] = float(i16) / 32768.0f;
        out.iq[2 * i + 1] = float(q16) / 32768.0f;
    }

    return true;
}

QVector<float> FmReceiver::iqDcBlock(const QVector<float> &iq)
{
    QVector<float> out(iq.size(), 0.0f);
    const float R = 0.999f;

    for (int n = 0; n < iq.size() / 2; ++n) {
        const float i = iq[2 * n];
        const float q = iq[2 * n + 1];

        const float yi = i - m_iqDcI_x1 + R * m_iqDcI_y1;
        const float yq = q - m_iqDcQ_x1 + R * m_iqDcQ_y1;

        out[2 * n] = yi;
        out[2 * n + 1] = yq;

        m_iqDcI_x1 = i;
        m_iqDcI_y1 = yi;
        m_iqDcQ_x1 = q;
        m_iqDcQ_y1 = yq;
    }

    return out;
}

QVector<float> FmReceiver::fmDemod(const QVector<float> &iq)
{
    const int nComplex = iq.size() / 2;
    QVector<float> y(nComplex, 0.0f);

    for (int i = 0; i < nComplex; ++i) {
        const float ci = iq[2 * i];
        const float cq = iq[2 * i + 1];
        const float re = m_prevI * ci + m_prevQ * cq;
        const float im = m_prevI * cq - m_prevQ * ci;
        y[i] = std::atan2(im, re);
        m_prevI = ci;
        m_prevQ = cq;
    }

    return y;
}

QVector<float> FmReceiver::dcBlock(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);
    const float R = 0.995f;

    for (int i = 0; i < x.size(); ++i) {
        const float xn = x[i];
        const float yn = xn - m_dcX1 + R * m_dcY1;
        y[i] = yn;
        m_dcX1 = xn;
        m_dcY1 = yn;
    }

    return y;
}

QVector<float> FmReceiver::deEmphasis(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);
    const double dt = 1.0 / double(INPUT_SAMPLE_RATE);
    const double tau = m_deemphasisUs * 1e-6;
    const float a = float(dt / (tau + dt));

    for (int i = 0; i < x.size(); ++i) {
        m_deempY1 = m_deempY1 + a * (x[i] - m_deempY1);
        y[i] = m_deempY1;
    }

    return y;
}

QVector<float> FmReceiver::firDecimate2(const QVector<float> &x)
{
    QVector<float> y;
    if (x.size() < 5)
        return y;

    y.reserve(x.size() / 2);
    for (int i = 0; i + 4 < x.size(); i += 2) {
        const float s = (x[i] + 4.0f * x[i + 1] + 6.0f * x[i + 2] + 4.0f * x[i + 3] + x[i + 4]) * (1.0f / 16.0f);
        y.push_back(s);
    }
    return y;
}

QVector<float> FmReceiver::audioLowPass(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);

    const float fs = float(OUTPUT_SAMPLE_RATE);
    const float fc = 12000.0f;
    const float a = 1.0f - qExp(-2.0f * float(M_PI) * fc / fs);

    for (int i = 0; i < x.size(); ++i) {
        m_lpf1 = m_lpf1 + a * (x[i] - m_lpf1);
        m_lpf2 = m_lpf2 + a * (m_lpf1 - m_lpf2);
        y[i] = m_lpf2;
    }

    return y;
}

QVector<float> FmReceiver::notch19k(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);

    const float fs = float(OUTPUT_SAMPLE_RATE);
    const float f0 = 19000.0f;
    const float r = 0.97f;
    const float w0 = 2.0f * float(M_PI) * f0 / fs;
    const float c = 2.0f * qCos(w0);

    for (int i = 0; i < x.size(); ++i) {
        const float xn = x[i];
        const float yn = xn - c * m_notch_x1 + m_notch_x2 + r * c * m_notch_y1 - r * r * m_notch_y2;
        y[i] = yn;
        m_notch_x2 = m_notch_x1;
        m_notch_x1 = xn;
        m_notch_y2 = m_notch_y1;
        m_notch_y1 = yn;
    }

    return y;
}

QVector<float> FmReceiver::softLimiter(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);
    const float norm = qTanH(1.6f);
    for (int i = 0; i < x.size(); ++i)
        y[i] = qTanH(1.6f * x[i]) / norm;
    return y;
}

QVector<qint16> FmReceiver::floatToPcm16(const QVector<float> &x)
{
    QVector<qint16> pcm;
    pcm.reserve(x.size());

    float peak = 1e-6f;
    for (int i = 0; i < x.size(); ++i)
        peak = qMax(peak, qAbs(x[i]));

    float gain = 13000.0f * m_manualOutputGain;
    if (m_autoGainEnabled) {
        const float target = 0.28f;
        const float wanted = target / peak;
        m_gainSmoothed = 0.995f * m_gainSmoothed + 0.005f * wanted;
        gain = qBound(1500.0f, m_gainSmoothed * 13000.0f * m_manualOutputGain, 26000.0f);
    }

    for (int i = 0; i < x.size(); ++i) {
        float s = m_muteEnabled ? 0.0f : x[i] * gain;
        if (s > 32767.0f) s = 32767.0f;
        if (s < -32768.0f) s = -32768.0f;
        pcm.push_back(qint16(s));
    }

    return pcm;
}

QVector<float> FmReceiver::makeLightSpectrum(const QVector<float> &iq) const
{
    const int nComplex = iq.size() / 2;
    const int N = qMin(nComplex, 256);
    QVector<float> out(N, -120.0f);
    if (N < 16)
        return out;

    for (int k = 0; k < N; ++k) {
        double re = 0.0;
        double im = 0.0;
        for (int n = 0; n < N; ++n) {
            const float w = 0.5f - 0.5f * qCos(float(2.0 * M_PI * n) / float(N - 1));
            const double xr = iq[2 * n] * w;
            const double xi = iq[2 * n + 1] * w;
            const double ang = -2.0 * M_PI * k * n / N;
            const double c = qCos(ang);
            const double s = qSin(ang);
            re += xr * c - xi * s;
            im += xr * s + xi * c;
        }
        const double mag = qSqrt(re * re + im * im) / N;
        out[k] = float(20.0 * qLn(mag + 1e-9) / qLn(10.0));
    }

    std::rotate(out.begin(), out.begin() + N / 2, out.end());
    return out;
}

bool FmReceiver::openWavFile(const QString &fileName)
{
    stopRecordingWav();

    m_wavFile.setFileName(fileName);
    if (!m_wavFile.open(QIODevice::WriteOnly)) {
        emit statusMessage(QString::fromUtf8("Не удалось открыть WAV файл: ") + fileName);
        return false;
    }

    m_wavDataBytes = 0;
    m_wavFileName = fileName;
    QByteArray header(44, 0);
    m_wavFile.write(header);

    emit recordingStateChanged(true, fileName);
    emit statusMessage(QString::fromUtf8("Запись WAV начата: ") + fileName);
    return true;
}

void FmReceiver::updateWavHeaderAndClose()
{
    if (!m_wavFile.isOpen())
        return;

    m_wavFile.seek(0);
    QDataStream ds(&m_wavFile);
    ds.setByteOrder(QDataStream::LittleEndian);

    const quint16 audioFormat = 1;
    const quint16 numChannels = 1;
    const quint32 sampleRate = OUTPUT_SAMPLE_RATE;
    const quint16 bitsPerSample = 16;
    const quint16 blockAlign = numChannels * bitsPerSample / 8;
    const quint32 byteRate = sampleRate * blockAlign;
    const quint32 riffSize = 36 + m_wavDataBytes;

    ds.writeRawData("RIFF", 4);
    ds << riffSize;
    ds.writeRawData("WAVE", 4);
    ds.writeRawData("fmt ", 4);
    ds << quint32(16);
    ds << audioFormat;
    ds << numChannels;
    ds << sampleRate;
    ds << byteRate;
    ds << blockAlign;
    ds << bitsPerSample;
    ds.writeRawData("data", 4);
    ds << m_wavDataBytes;

    m_wavFile.close();
}

bool FmReceiver::startRecordingWav(const QString &fileName)
{
    return openWavFile(fileName);
}

void FmReceiver::stopRecordingWav()
{
    if (!m_wavFile.isOpen())
        return;

    const QString name = m_wavFileName;
    updateWavHeaderAndClose();
    emit recordingStateChanged(false, QString());
    emit statusMessage(QString::fromUtf8("Запись WAV остановлена: ") + name);
    m_wavFileName.clear();
}

bool FmReceiver::isRecording() const
{
    return m_wavFile.isOpen();
}

void FmReceiver::onReadyRead()
{
    while (m_udp->hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(int(m_udp->pendingDatagramSize()));
        m_udp->readDatagram(datagram.data(), datagram.size());

        PacketInfo packet;
        if (!parsePacket(datagram, packet))
            continue;

        if (m_havePrevCounter) {
            const quint16 expected = quint16(m_prevCounter + 1);
            if (packet.counter != expected) {
                const quint16 diff = quint16(packet.counter - expected);
                m_lostPackets += diff;
                emit lossCounterUpdated(m_lostPackets);
            }
        }
        m_prevCounter = packet.counter;
        m_havePrevCounter = true;

        QVector<float> iq = iqDcBlock(packet.iq);
        QVector<float> demod = fmDemod(iq);

        if (m_dcBlockEnabled)
            demod = dcBlock(demod);

        demod = deEmphasis(demod);
        demod = firDecimate2(demod);

        if (m_noiseFilterEnabled)
            demod = audioLowPass(demod);

        if (m_notch19kEnabled)
            demod = notch19k(demod);

        demod = softLimiter(demod);

        float peak = 0.0f;
        for (int i = 0; i < demod.size(); ++i)
            peak = qMax(peak, qAbs(demod[i]));
        emit levelUpdated(qMin(1.0f, peak * 2.0f));

        const QVector<qint16> pcm = floatToPcm16(demod);
        m_audioDevice->appendPcm16Mono(pcm);

        if (m_wavFile.isOpen() && !pcm.isEmpty()) {
            m_wavFile.write(reinterpret_cast<const char*>(pcm.constData()), pcm.size() * int(sizeof(qint16)));
            m_wavDataBytes += pcm.size() * int(sizeof(qint16));
        }

        ++m_packets;
        emit packetCounterUpdated(m_packets);
        emit bufferUpdated(m_audioDevice->bufferedBytes());

        if ((m_packets - m_lastSpectrumPacket) >= 20) {
            m_lastSpectrumPacket = m_packets;
            emit spectrumUpdated(makeLightSpectrum(iq));
        }

        if ((m_packets % 200) == 0) {
            emit statusMessage(QString::fromUtf8("Пакеты: %1, потери: %2, аудио-буфер: %3 байт")
                               .arg(m_packets)
                               .arg(m_lostPackets)
                               .arg(m_audioDevice->bufferedBytes()));
        }
    }
}
