#include "mainwindow.h"
#include "fmreceiver.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QSlider>
#include <QComboBox>
#include <QPlainTextEdit>
#include <QPainter>
#include <QDateTime>
#include <QHostAddress>
#include <QMessageBox>

SpectrumWidget::SpectrumWidget(QWidget *parent)
    : QWidget(parent)
{
    setMinimumHeight(220);
}

void SpectrumWidget::setSpectrum(const QVector<float> &values)
{
    m_values = values;
    update();
}

void SpectrumWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.fillRect(rect(), QColor(18, 18, 18));

    p.setPen(QColor(55, 55, 55));
    for (int i = 0; i <= 10; ++i) {
        int y = i * height() / 10;
        p.drawLine(0, y, width(), y);
    }
    for (int i = 0; i <= 8; ++i) {
        int x = i * width() / 8;
        p.drawLine(x, 0, x, height());
    }

    if (m_values.isEmpty()) {
        p.setPen(Qt::lightGray);
        p.drawText(rect(), Qt::AlignCenter, QString::fromUtf8("Спектр появится после старта приёма"));
        return;
    }

    QPolygon poly;
    poly.reserve(m_values.size());

    const float minDb = -100.0f;
    const float maxDb = 0.0f;

    for (int i = 0; i < m_values.size(); ++i) {
        float normX = (m_values.size() == 1) ? 0.0f : float(i) / float(m_values.size() - 1);
        float v = (m_values[i] - minDb) / (maxDb - minDb);
        if (v < 0.0f) v = 0.0f;
        if (v > 1.0f) v = 1.0f;

        int x = int(normX * (width() - 1));
        int y = int((1.0f - v) * (height() - 1));
        poly << QPoint(x, y);
    }

    p.setRenderHint(QPainter::Antialiasing, true);
    p.setPen(QPen(QColor(0, 220, 120), 2));
    p.drawPolyline(poly);

    p.setPen(Qt::gray);
    p.drawText(8, 16, "-48 кГц");
    p.drawText(width() / 2 - 20, 16, "0");
    p.drawText(width() - 55, 16, "+48 кГц");
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      m_receiver(new FmReceiver(this))
{
    buildUi();

    connect(m_receiver, SIGNAL(statusMessage(QString)), this, SLOT(appendStatus(QString)));
    connect(m_receiver, SIGNAL(spectrumUpdated(QVector<float>)), this, SLOT(onSpectrumUpdated(QVector<float>)));
    connect(m_receiver, SIGNAL(levelUpdated(float)), this, SLOT(onLevelUpdated(float)));
    connect(m_receiver, SIGNAL(packetCounterUpdated(quint64)), this, SLOT(onPacketCounterUpdated(quint64)));
}

void MainWindow::buildUi()
{
    setWindowTitle(QString::fromUtf8("Qt5 FM Receiver for AD9361"));
    resize(900, 700);

    QWidget *central = new QWidget(this);
    setCentralWidget(central);

    QVBoxLayout *root = new QVBoxLayout(central);

    QGroupBox *controlBox = new QGroupBox(QString::fromUtf8("Управление"), this);
    QGridLayout *grid = new QGridLayout(controlBox);

    grid->addWidget(new QLabel("Bind IP:", this), 0, 0);
    m_ipEdit = new QLineEdit("192.168.200.63", this);
    grid->addWidget(m_ipEdit, 0, 1);

    grid->addWidget(new QLabel(QString::fromUtf8("UDP порт:")), 0, 2);
    m_portEdit = new QLineEdit("60000", this);
    grid->addWidget(m_portEdit, 0, 3);

    m_startStopButton = new QPushButton(QString::fromUtf8("Старт"), this);
    grid->addWidget(m_startStopButton, 0, 4);

    grid->addWidget(new QLabel(QString::fromUtf8("Громкость:")), 1, 0);
    m_volumeSlider = new QSlider(Qt::Horizontal, this);
    m_volumeSlider->setRange(0, 100);
    m_volumeSlider->setValue(70);
    grid->addWidget(m_volumeSlider, 1, 1, 1, 2);

    grid->addWidget(new QLabel(QString::fromUtf8("De-emphasis:")), 1, 3);
    m_deempCombo = new QComboBox(this);
    m_deempCombo->addItem("50 us", 50.0);
    m_deempCombo->addItem("75 us", 75.0);
    grid->addWidget(m_deempCombo, 1, 4);

    root->addWidget(controlBox);

    QHBoxLayout *infoRow = new QHBoxLayout();
    m_stateLabel = new QLabel(QString::fromUtf8("Состояние: остановлен"), this);
    m_packetsLabel = new QLabel(QString::fromUtf8("Пакеты: 0"), this);
    m_levelLabel = new QLabel(QString::fromUtf8("Уровень FM: 0.00"), this);
    infoRow->addWidget(m_stateLabel);
    infoRow->addStretch();
    infoRow->addWidget(m_packetsLabel);
    infoRow->addStretch();
    infoRow->addWidget(m_levelLabel);
    root->addLayout(infoRow);

    QGroupBox *specBox = new QGroupBox(QString::fromUtf8("Спектр IQ"), this);
    QVBoxLayout *specLayout = new QVBoxLayout(specBox);
    m_spectrum = new SpectrumWidget(this);
    specLayout->addWidget(m_spectrum);
    root->addWidget(specBox, 1);

    QGroupBox *logBox = new QGroupBox(QString::fromUtf8("Журнал"), this);
    QVBoxLayout *logLayout = new QVBoxLayout(logBox);
    m_log = new QPlainTextEdit(this);
    m_log->setReadOnly(true);
    logLayout->addWidget(m_log);
    root->addWidget(logBox, 1);

    connect(m_startStopButton, SIGNAL(clicked()), this, SLOT(onStartStopClicked()));
    connect(m_volumeSlider, &QSlider::valueChanged, [this](int value) {
        m_receiver->setVolumePercent(value);
    });
    connect(m_deempCombo, QOverload<int>::of(&QComboBox::currentIndexChanged), [this](int index) {
        m_receiver->setDeemphasisUs(m_deempCombo->itemData(index).toDouble());
    });

    appendStatus(QString::fromUtf8("Готово. Укажи IP/порт и нажми Старт."));
}

void MainWindow::onStartStopClicked()
{
    if (!m_receiver->isRunning()) {
        QHostAddress addr;
        if (!addr.setAddress(m_ipEdit->text().trimmed())) {
            QMessageBox::warning(this, QString::fromUtf8("Ошибка"), QString::fromUtf8("Неверный IP адрес."));
            return;
        }

        bool ok = false;
        quint16 port = m_portEdit->text().toUShort(&ok);
        if (!ok || port == 0) {
            QMessageBox::warning(this, QString::fromUtf8("Ошибка"), QString::fromUtf8("Неверный UDP порт."));
            return;
        }

        m_receiver->setVolumePercent(m_volumeSlider->value());
        m_receiver->setDeemphasisUs(m_deempCombo->currentData().toDouble());

        if (m_receiver->start(addr, port)) {
            m_stateLabel->setText(QString::fromUtf8("Состояние: приём идёт"));
            m_startStopButton->setText(QString::fromUtf8("Стоп"));
        }
    } else {
        m_receiver->stop();
        m_stateLabel->setText(QString::fromUtf8("Состояние: остановлен"));
        m_startStopButton->setText(QString::fromUtf8("Старт"));
    }
}

void MainWindow::onSpectrumUpdated(const QVector<float> &values)
{
    m_spectrum->setSpectrum(values);
}

void MainWindow::onLevelUpdated(float value)
{
    m_levelLabel->setText(QString::fromUtf8("Уровень FM: %1").arg(value, 0, 'f', 3));
}

void MainWindow::onPacketCounterUpdated(quint64 count)
{
    m_packetsLabel->setText(QString::fromUtf8("Пакеты: %1").arg(count));
}

void MainWindow::appendStatus(const QString &text)
{
    const QString t = QDateTime::currentDateTime().toString("HH:mm:ss");
    m_log->appendPlainText(QString("[%1] %2").arg(t, text));
}
