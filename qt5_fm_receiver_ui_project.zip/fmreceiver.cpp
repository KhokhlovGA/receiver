#include "fmreceiver.h"

#include <QtMath>
#include <QAudioFormat>
#include <QDataStream>
#include <QDebug>
#include <algorithm>

static const int HEADER_SIZE = 24;
static const int SAMPLES_PER_PACKET = 350;
static const int BYTES_PER_COMPLEX_INT16 = 4;
static const quint8 RX_PACKET_ID = 0x52;

AudioBufferDevice::AudioBufferDevice(QObject *parent)
    : QIODevice(parent),
      m_readPos(0)
{
}

void AudioBufferDevice::start()
{
    open(QIODevice::ReadOnly);
}

void AudioBufferDevice::stop()
{
    close();
    m_buffer.clear();
    m_readPos = 0;
}

qint64 AudioBufferDevice::readData(char *data, qint64 maxlen)
{
    qint64 available = m_buffer.size() - m_readPos;
    if (available <= 0) {
        memset(data, 0, size_t(maxlen));
        return maxlen;
    }

    qint64 toRead = qMin(maxlen, available);
    memcpy(data, m_buffer.constData() + m_readPos, size_t(toRead));
    m_readPos += int(toRead);

    if (toRead < maxlen) {
        memset(data + toRead, 0, size_t(maxlen - toRead));
    }

    if (m_readPos > 8192) {
        m_buffer.remove(0, m_readPos);
        m_readPos = 0;
    }

    return maxlen;
}

qint64 AudioBufferDevice::writeData(const char *, qint64)
{
    return -1;
}

qint64 AudioBufferDevice::bytesAvailable() const
{
    return (m_buffer.size() - m_readPos) + QIODevice::bytesAvailable();
}

void AudioBufferDevice::appendPcm16Mono(const QVector<qint16> &samples)
{
    const int oldSize = m_buffer.size();
    m_buffer.resize(oldSize + samples.size() * int(sizeof(qint16)));
    memcpy(m_buffer.data() + oldSize, samples.constData(), size_t(samples.size() * int(sizeof(qint16))));

    if (m_buffer.size() > 48000 * 2 * 4) { // ограничение буфера около 4 секунд
        int drop = m_buffer.size() - 48000 * 2 * 2;
        m_buffer.remove(0, drop);
        m_readPos = qMax(0, m_readPos - drop);
    }
}

int AudioBufferDevice::bufferedBytes() const
{
    return m_buffer.size() - m_readPos;
}

FmReceiver::FmReceiver(QObject *parent)
    : QObject(parent),
      m_udp(new QUdpSocket(this)),
      m_audio(nullptr),
      m_audioDevice(new AudioBufferDevice(this)),
      m_running(false),
      m_packets(0),
      m_prevI(1.0f),
      m_prevQ(0.0f),
      m_dcX1(0.0f),
      m_dcY1(0.0f),
      m_deempY1(0.0f),
      m_deemphasisUs(50.0),
      m_inputSampleRate(96000),
      m_outputSampleRate(48000)
{
    connect(m_udp, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

FmReceiver::~FmReceiver()
{
    stop();
}

bool FmReceiver::start(const QHostAddress &bindAddress, quint16 port)
{
    if (m_running) {
        stop();
    }

    QAudioFormat fmt;
    fmt.setSampleRate(m_outputSampleRate);
    fmt.setChannelCount(1);
    fmt.setSampleSize(16);
    fmt.setCodec("audio/pcm");
    fmt.setByteOrder(QAudioFormat::LittleEndian);
    fmt.setSampleType(QAudioFormat::SignedInt);

    m_audio = new QAudioOutput(fmt, this);
    m_audio->setBufferSize(48000);
    m_audioDevice->start();
    m_audio->start(m_audioDevice);

    bool ok = m_udp->bind(bindAddress, port, QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    if (!ok) {
        emit statusMessage(QString::fromUtf8("Ошибка bind UDP: ") + m_udp->errorString());
        if (m_audio) {
            m_audio->stop();
            m_audio->deleteLater();
            m_audio = nullptr;
        }
        m_audioDevice->stop();
        return false;
    }

    m_prevI = 1.0f;
    m_prevQ = 0.0f;
    m_dcX1 = m_dcY1 = 0.0f;
    m_deempY1 = 0.0f;
    m_packets = 0;
    m_running = true;
    emit statusMessage(QString::fromUtf8("Приём запущен: %1:%2").arg(bindAddress.toString()).arg(port));
    return true;
}

void FmReceiver::stop()
{
    if (m_udp->state() == QUAbstractSocket::BoundState) {
        m_udp->close();
    }

    if (m_audio) {
        m_audio->stop();
        m_audio->deleteLater();
        m_audio = nullptr;
    }

    m_audioDevice->stop();
    m_running = false;
    emit statusMessage(QString::fromUtf8("Приём остановлен"));
}

bool FmReceiver::isRunning() const
{
    return m_running;
}

void FmReceiver::setVolumePercent(int value)
{
    if (m_audio) {
        m_audio->setVolume(qBound(0, value, 100) / 100.0);
    }
}

void FmReceiver::setDeemphasisUs(double value)
{
    m_deemphasisUs = value;
}

void FmReceiver::setOutputSampleRate(int sampleRate)
{
    m_outputSampleRate = sampleRate;
}

bool FmReceiver::parsePacket(const QByteArray &datagram, QVector<float> &iqOut)
{
    if (datagram.size() < HEADER_SIZE + SAMPLES_PER_PACKET * BYTES_PER_COMPLEX_INT16) {
        return false;
    }

    const uchar *p = reinterpret_cast<const uchar*>(datagram.constData());
    if (p[0] != RX_PACKET_ID) {
        return false;
    }

    const quint16 sampleCount = (quint16(p[2]) << 8) | quint16(p[3]);
    if (sampleCount != SAMPLES_PER_PACKET) {
        return false;
    }

    iqOut.resize(sampleCount * 2);
    const char *samples = datagram.constData() + HEADER_SIZE;

    for (int i = 0; i < sampleCount; ++i) {
        const int pos = i * 4;
        const qint16 i16 = qint16((quint8)samples[pos] | (quint8(samples[pos + 1]) << 8));
        const qint16 q16 = qint16((quint8)samples[pos + 2] | (quint8(samples[pos + 3]) << 8));
        iqOut[2 * i] = float(i16) / 32768.0f;
        iqOut[2 * i + 1] = float(q16) / 32768.0f;
    }

    return true;
}

QVector<float> FmReceiver::makeSpectrum(const QVector<float> &iq)
{
    const int nComplex = iq.size() / 2;
    const int N = qMin(nComplex, 512);
    QVector<float> out(N, -120.0f);

    if (N < 8) {
        return out;
    }

    for (int k = 0; k < N; ++k) {
        double re = 0.0;
        double im = 0.0;
        for (int n = 0; n < N; ++n) {
            const float wi = 0.5f - 0.5f * qCos(float(2.0 * M_PI * n) / float(N - 1));
            const double xr = iq[2 * n] * wi;
            const double xi = iq[2 * n + 1] * wi;
            const double ang = -2.0 * M_PI * k * n / N;
            const double c = qCos(ang);
            const double s = qSin(ang);
            re += xr * c - xi * s;
            im += xr * s + xi * c;
        }
        const double mag = qSqrt(re * re + im * im) / N;
        out[k] = float(20.0 * qLn(mag + 1e-9) / qLn(10.0));
    }

    std::rotate(out.begin(), out.begin() + N / 2, out.end());
    return out;
}

QVector<float> FmReceiver::fmDemod(const QVector<float> &iq)
{
    const int nComplex = iq.size() / 2;
    QVector<float> y(nComplex, 0.0f);

    for (int i = 0; i < nComplex; ++i) {
        const float ci = iq[2 * i];
        const float cq = iq[2 * i + 1];
        const float re = m_prevI * ci + m_prevQ * cq;
        const float im = m_prevI * cq - m_prevQ * ci;
        y[i] = std::atan2(im, re);
        m_prevI = ci;
        m_prevQ = cq;
    }

    return y;
}

QVector<float> FmReceiver::dcBlock(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);
    const float R = 0.995f;

    for (int i = 0; i < x.size(); ++i) {
        float xn = x[i];
        float yn = xn - m_dcX1 + R * m_dcY1;
        y[i] = yn;
        m_dcX1 = xn;
        m_dcY1 = yn;
    }
    return y;
}

QVector<float> FmReceiver::deEmphasis(const QVector<float> &x)
{
    QVector<float> y(x.size(), 0.0f);
    const double dt = 1.0 / double(m_inputSampleRate);
    const double tau = m_deemphasisUs * 1e-6;
    const float a = float(dt / (tau + dt));

    for (int i = 0; i < x.size(); ++i) {
        m_deempY1 = m_deempY1 + a * (x[i] - m_deempY1);
        y[i] = m_deempY1;
    }
    return y;
}

QVector<qint16> FmReceiver::decimateTo48k(const QVector<float> &x)
{
    const int decim = qMax(1, m_inputSampleRate / m_outputSampleRate);
    QVector<qint16> pcm;
    pcm.reserve(x.size() / decim + 1);

    for (int i = 0; i < x.size(); i += decim) {
        float s = x[i] * 14000.0f;
        if (s > 32767.0f) s = 32767.0f;
        if (s < -32768.0f) s = -32768.0f;
        pcm.push_back(qint16(s));
    }
    return pcm;
}

void FmReceiver::onReadyRead()
{
    while (m_udp->hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(int(m_udp->pendingDatagramSize()));
        QHostAddress sender;
        quint16 senderPort = 0;
        m_udp->readDatagram(datagram.data(), datagram.size(), &sender, &senderPort);

        QVector<float> iq;
        if (!parsePacket(datagram, iq)) {
            continue;
        }

        QVector<float> spectrum = makeSpectrum(iq);
        emit spectrumUpdated(spectrum);

        QVector<float> demod = fmDemod(iq);
        demod = dcBlock(demod);
        demod = deEmphasis(demod);

        float peak = 0.0f;
        for (int i = 0; i < demod.size(); ++i) {
            peak = qMax(peak, qAbs(demod[i]));
        }
        emit levelUpdated(peak);

        QVector<qint16> pcm = decimateTo48k(demod);
        m_audioDevice->appendPcm16Mono(pcm);

        ++m_packets;
        emit packetCounterUpdated(m_packets);

        if ((m_packets % 100) == 0) {
            emit statusMessage(QString::fromUtf8("Пакеты: %1, аудио-буфер: %2 байт")
                               .arg(m_packets)
                               .arg(m_audioDevice->bufferedBytes()));
        }
    }
}
