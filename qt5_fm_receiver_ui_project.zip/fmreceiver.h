#ifndef FMRECEIVER_H
#define FMRECEIVER_H

#include <QObject>
#include <QUdpSocket>
#include <QAudioOutput>
#include <QIODevice>
#include <QVector>
#include <QByteArray>
#include <QHostAddress>

class AudioBufferDevice : public QIODevice
{
    Q_OBJECT
public:
    explicit AudioBufferDevice(QObject *parent = nullptr);

    void start();
    void stop();
    qint64 readData(char *data, qint64 maxlen) override;
    qint64 writeData(const char *data, qint64 len) override;
    qint64 bytesAvailable() const override;
    void appendPcm16Mono(const QVector<qint16> &samples);
    int bufferedBytes() const;

private:
    QByteArray m_buffer;
    int m_readPos;
};

class FmReceiver : public QObject
{
    Q_OBJECT
public:
    explicit FmReceiver(QObject *parent = nullptr);
    ~FmReceiver();

    bool start(const QHostAddress &bindAddress, quint16 port);
    void stop();
    bool isRunning() const;

    void setVolumePercent(int value);
    void setDeemphasisUs(double value);
    void setOutputSampleRate(int sampleRate);

signals:
    void statusMessage(const QString &text);
    void levelUpdated(float level);
    void spectrumUpdated(const QVector<float> &spectrumDb);
    void packetCounterUpdated(quint64 packets);

private slots:
    void onReadyRead();

private:
    bool parsePacket(const QByteArray &datagram, QVector<float> &iqOut);
    QVector<float> makeSpectrum(const QVector<float> &iq);
    QVector<float> fmDemod(const QVector<float> &iq);
    QVector<float> dcBlock(const QVector<float> &x);
    QVector<float> deEmphasis(const QVector<float> &x);
    QVector<qint16> decimateTo48k(const QVector<float> &x);

    QUdpSocket *m_udp;
    QAudioOutput *m_audio;
    AudioBufferDevice *m_audioDevice;

    bool m_running;
    quint64 m_packets;
    float m_prevI;
    float m_prevQ;
    float m_dcX1;
    float m_dcY1;
    float m_deempY1;
    double m_deemphasisUs;
    int m_inputSampleRate;
    int m_outputSampleRate;
};

#endif // FMRECEIVER_H
