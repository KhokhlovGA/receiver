#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>

class QLineEdit;
class QPushButton;
class QLabel;
class QSlider;
class QComboBox;
class QPlainTextEdit;
class QWidget;
class FmReceiver;

class SpectrumWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SpectrumWidget(QWidget *parent = nullptr);
    void setSpectrum(const QVector<float> &values);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QVector<float> m_values;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    void onStartStopClicked();
    void onSpectrumUpdated(const QVector<float> &values);
    void onLevelUpdated(float value);
    void onPacketCounterUpdated(quint64 count);
    void appendStatus(const QString &text);

private:
    void buildUi();

    FmReceiver *m_receiver;

    QLineEdit *m_ipEdit;
    QLineEdit *m_portEdit;
    QPushButton *m_startStopButton;
    QSlider *m_volumeSlider;
    QComboBox *m_deempCombo;
    QLabel *m_stateLabel;
    QLabel *m_packetsLabel;
    QLabel *m_levelLabel;
    SpectrumWidget *m_spectrum;
    QPlainTextEdit *m_log;
};

#endif // MAINWINDOW_H
