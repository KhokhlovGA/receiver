#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>

class QLineEdit;
class QPushButton;
class QLabel;
class QSlider;
class QComboBox;
class QCheckBox;
class QPlainTextEdit;
class QProgressBar;
class FmReceiver;
class QWidget;

class SpectrumWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SpectrumWidget(QWidget *parent = nullptr);
    void setSpectrum(const QVector<float> &values);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QVector<float> m_values;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    void onStartStopClicked();
    void onRecordClicked();
    void onLevelUpdated(float level01);
    void onPacketCounterUpdated(quint64 count);
    void onLossCounterUpdated(quint64 count);
    void onBufferUpdated(int bytes);
    void onSpectrumUpdated(const QVector<float> &values);
    void onRecordingStateChanged(bool recording, const QString &fileName);
    void appendStatus(const QString &text);

private:
    void buildUi();

    FmReceiver *m_receiver;

    QLineEdit *m_ipEdit;
    QLineEdit *m_portEdit;
    QPushButton *m_startStopButton;
    QPushButton *m_recordButton;
    QSlider *m_volumeSlider;
    QSlider *m_outputGainSlider;
    QComboBox *m_deempCombo;
    QCheckBox *m_autoGainCheck;
    QCheckBox *m_dcBlockCheck;
    QCheckBox *m_muteCheck;

    QLabel *m_stateLabel;
    QLabel *m_packetsLabel;
    QLabel *m_lossLabel;
    QLabel *m_bufferLabel;
    QLabel *m_recordLabel;
    QProgressBar *m_levelBar;
    SpectrumWidget *m_spectrum;
    QPlainTextEdit *m_log;
};

#endif // MAINWINDOW_H
